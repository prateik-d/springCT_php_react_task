import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';

function App() 
{

  const [users, setUsers] = useState();

  const fetchData = () => {
      fetch('http://127.0.0.1:8000/api/company')
      .then((response) => response.json())
      .then((data) => {
        setUsers(data)
      });
  }

  useEffect(() => {
    
    fetchData();
  }, [])

  return (

    

    <div className="App">

        
      <table>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
        </tr>
           {
             users.length > 0 && (
               users.map((user)=> 
                <tr>
                  <th>{user.name}</th>
                  <th>{user.email}</th>
                  <th>{user.phone}</th>
                </tr>
              )
            )
          } 
      </table>
  
    </div>
  );
}

export default App;
