<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Response;


class userApiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       
        $users = DB::table('users')->join('company', 'users.id', '=', 'company.users')->
                    select('users.*', 'company.name as cname')->get();

        // dd($users);
        return Response::json($users);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $name = $request->input('name');
            $email = $request->input('email');
            $phone = $request->input('phone');
            $created_at = date('Y-m-d H:i:s');
            $updated_at = date('Y-m-d H:i:s');


            $data = array(
                            'name' => $name, 
                            'email' => $email,
                            'phone' => $phone,
                            'created_at' => $created_at,
                            'updated_at' => $updated_at,
                        );
            // dd($data);


            $res =     DB::table('users')->insert( $data );

            // dd($res);

            if($res)
            {
                $response = array(
                                'status' => 200,
                                'message' => 'Data Inserted Successfully'
                            );

            }
            else
            {
                $response = array(
                                'status' => 400,
                                'message' => 'Something went wrong!'
                            );
            }


            // print_r($response);
            return Response::json($response);
        }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //

        
    }
}
