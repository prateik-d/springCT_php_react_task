<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Response;



class companyApiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        // dd('aaa');

        $companies = DB::table('company')->get();

        // dd($companies);

            return Response::json($companies);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->input('name'));

        $name = $request->input('name');
        $city = $request->input('city');
        $created_at = date('Y-m-d H:i:s');
        $updated_at = date('Y-m-d H:i:s');


        $data = array(
                        'name' => $name, 
                        'city' => $city,
                        'created_at' => $created_at,
                        'updated_at' => $updated_at,
                    );
        // dd($data);

        
        $res = DB::table('company')->insert($data);

        if($res)
        {
            $response = array(
                            'status' => 200,
                            'message' => 'Data Inserted Successfully'
                        );

        }
        else
        {
            $response = array(
                            'status' => 400,
                            'message' => 'Something went wrong!'
                        );
        }

            return Response::json($response);

        // print_r($response);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $company = DB::table('company')->where($id);
        // dd($company);

        if($company)
        {
            $company_id = $request->input('company');
            $user_id = $request->input('users');

            dd($company_id);

            $res =  DB::table('company')->
                where('id', $id)->
                update('users', $user_id);

            if($res)
            {
                $response = array(
                                'status' => 200,
                                'message' => 'Data Inserted Successfully'
                            );

            }
            else
            {
                $response = array(
                                'status' => 400,
                                'message' => 'Something went wrong!'
                            );
            }


        }
        else
        {
            $response = array(
                            'status' => 400,
                            'message' => 'Company Not Found'
                        );
        }
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $res = DB::table('company')->delete($id);


        if($res)
        {
            $response = array(
                            'status' => 200,
                            'message' => 'Data Deleted Successfully'
                        );

        }
        else
        {
            $response = array(
                            'status' => 400,
                            'message' => 'Something went wrong!'
                        );
        }


        return Response::json($response);

    }
}
